// Run with: node --test
// Uses a tiny fake database so the logic can be tested without Postgres.
const test = require('node:test');
const assert = require('node:assert');
const { createGoal, listGoals, addToGoal, deleteGoal, GoalError } = require('../src/goals');

function goalRow(o = {}) {
  return { id: 'g1', teen_id: 't', title: 'Headphones', target_paise: 200000, saved_paise: 0,
    product_name: null, product_image_url: null, product_link: null, created_at: 'now', ...o };
}

function fakeDb({ balance = 100000, alreadySet = 0, goal = goalRow(), deleteCount = 1 } = {}) {
  const log = [];
  const handle = async (sql, params) => {
    if (/INSERT INTO goals/.test(sql)) {
      log.push(`INSERT ${JSON.stringify(params)}`);
      return { rows: [goalRow({ title: params[1], target_paise: params[2], product_name: params[3], product_image_url: params[4], product_link: params[5] })] };
    }
    if (/DELETE FROM goals/.test(sql)) return { rowCount: deleteCount, rows: [] };
    if (/FROM wallets/.test(sql)) return { rows: [{ id: 'w1' }] };
    if (/FROM goals WHERE id/.test(sql)) return { rows: goal ? [goal] : [] };
    if (/AS balance/.test(sql)) return { rows: [{ balance }] };
    if (/AS total/.test(sql)) return { rows: [{ total: alreadySet }] };
    if (/UPDATE goals/.test(sql)) { log.push(`UPDATE +${params[0]}`); return { rows: [{ ...goal, saved_paise: Number(goal.saved_paise) + params[0] }] }; }
    if (/FROM goals WHERE teen_id/.test(sql)) return { rows: [goalRow({ saved_paise: 50000 })] };
    log.push(sql.trim()); // BEGIN / COMMIT / ROLLBACK
    return { rows: [] };
  };
  const client = { query: handle, release() { log.push('RELEASE'); } };
  return { query: handle, connect: async () => client, log };
}

const product = { name: 'Wireless Headphones', imageUrl: 'https://i/h.jpg', link: 'https://buy/h', pricePaise: 199900 };

test('createGoal from a product uses its name and price', async () => {
  const g = await createGoal(fakeDb(), 't', { product });
  assert.strictEqual(g.title, 'Wireless Headphones');
  assert.strictEqual(g.targetPaise, 199900);
  assert.deepStrictEqual(g.product, { name: 'Wireless Headphones', imageUrl: 'https://i/h.jpg', link: 'https://buy/h' });
});

test('createGoal without a product works with title and target', async () => {
  const g = await createGoal(fakeDb(), 't', { title: ' Bike ', targetPaise: 500000 });
  assert.strictEqual(g.title, 'Bike');
  assert.strictEqual(g.product, null);
});

test('createGoal rejects bad targets and missing title', async () => {
  const db = fakeDb();
  for (const targetPaise of [0, -5, 10.5, 'abc']) {
    await assert.rejects(() => createGoal(db, 't', { title: 'x', targetPaise }), (e) => e.code === 'INVALID_TARGET');
  }
  await assert.rejects(() => createGoal(db, 't', { targetPaise: 100 }), (e) => e.code === 'TITLE_REQUIRED');
  // product in dollars (no pricePaise) and no manual target -> must not guess
  await assert.rejects(() => createGoal(db, 't', { product: { name: 'x', pricePaise: null } }), (e) => e.code === 'INVALID_TARGET');
});

test('listGoals returns progress percent', async () => {
  const [g] = await listGoals(fakeDb(), 't');
  assert.strictEqual(g.percent, 25);
  assert.strictEqual(g.reached, false);
});

test('addToGoal sets money aside and commits', async () => {
  const db = fakeDb();
  const g = await addToGoal(db, 't', 'g1', 30000);
  assert.strictEqual(g.savedPaise, 30000);
  assert.ok(db.log.includes('UPDATE +30000'));
  assert.ok(db.log.includes('COMMIT'));
  assert.ok(db.log.includes('RELEASE'));
});

test('addToGoal refuses more than what is available (balance minus already set aside)', async () => {
  const db = fakeDb({ balance: 100000, alreadySet: 80000 });
  await assert.rejects(() => addToGoal(db, 't', 'g1', 30000), (e) => e.code === 'NOT_ENOUGH_AVAILABLE');
  assert.ok(db.log.includes('ROLLBACK'));
  assert.ok(!db.log.some((l) => l.startsWith('UPDATE')));
  assert.ok(db.log.includes('RELEASE'));
});

test('addToGoal on someone else\'s / missing goal is refused', async () => {
  await assert.rejects(() => addToGoal(fakeDb({ goal: null }), 't', 'nope', 100), (e) => e.code === 'GOAL_NOT_FOUND');
});

test('addToGoal rejects bad amounts', async () => {
  for (const a of [0, -1, 2.5]) {
    await assert.rejects(() => addToGoal(fakeDb(), 't', 'g1', a), (e) => e instanceof GoalError && e.code === 'INVALID_AMOUNT');
  }
});

test('deleteGoal works, and refuses a goal that is not theirs', async () => {
  assert.deepStrictEqual(await deleteGoal(fakeDb(), 't', 'g1'), { deleted: true });
  await assert.rejects(() => deleteGoal(fakeDb({ deleteCount: 0 }), 't', 'x'), (e) => e.code === 'GOAL_NOT_FOUND');
});
