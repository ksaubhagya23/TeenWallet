// src/channel3.js
// Product search through Channel3 (https://api.trychannel3.com).
// The API key is read from the CHANNEL3_API_KEY environment variable. Never hard-code it.

const fs = require('fs');
const path = require('path');

const SEARCH_URL = 'https://api.trychannel3.com/v1/search';
const TIMEOUT_MS = 8000;

// Channel3's docs show the price in a few shapes (price.price, price.amount, or a flat
// number), and images as images[].url or image_url. This reads all of them so a small
// change on their side doesn't break the app.
function normalizeProduct(raw) {
  const offer = (raw.offers && raw.offers[0]) || {};
  let amount = null;
  let currency = null;

  if (offer.price && typeof offer.price === 'object') {
    amount = offer.price.price ?? offer.price.amount ?? null;
    currency = offer.price.currency ?? offer.currency ?? null;
  } else if (typeof offer.price === 'number') {
    amount = offer.price;
    currency = offer.currency ?? null;
  } else if (raw.price && typeof raw.price === 'object') {
    amount = raw.price.price ?? raw.price.amount ?? null;
    currency = raw.price.currency ?? null;
  }

  const firstImage = raw.images && raw.images[0];
  const imageUrl =
    (firstImage && (firstImage.url || (typeof firstImage === 'string' ? firstImage : null))) ||
    raw.image_url ||
    (raw.image_urls && raw.image_urls[0]) ||
    null;

  return {
    productId: raw.id || null,
    name: raw.title || raw.name || null,
    brand: (raw.brand && raw.brand.name) || raw.brand_name || null,
    imageUrl,
    link: offer.url || raw.url || null,
    merchant: offer.domain || offer.merchant_domain || null,
    price: amount,
    currency,
    // Only filled in when the price is in rupees, so we never save a wrong amount.
    pricePaise: amount != null && currency === 'INR' ? Math.round(amount * 100) : null,
  };
}

function loadFallback() {
  const file = path.join(__dirname, '..', 'data', 'channel3-sample.json');
  const json = JSON.parse(fs.readFileSync(file, 'utf8'));
  return (json.products || []).map(normalizeProduct);
}

// Returns { products, fromFallback }.
// If Channel3 is slow, down, or the key is missing, returns the saved sample instead,
// so the demo never shows an empty screen.
async function searchProducts(query, { limit = 10, fetchFn = fetch, apiKey = process.env.CHANNEL3_API_KEY } = {}) {
  if (!query || !String(query).trim()) return { products: [], fromFallback: false };

  try {
    if (!apiKey) throw new Error('CHANNEL3_API_KEY is not set');
    const res = await fetchFn(SEARCH_URL, {
      method: 'POST',
      headers: { 'x-api-key': apiKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: String(query).trim(), limit }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
    if (!res.ok) throw new Error(`Channel3 returned ${res.status}`);
    const data = await res.json();
    return { products: (data.products || []).map(normalizeProduct), fromFallback: false };
  } catch (err) {
    console.warn('Channel3 search failed, using saved sample:', err.message);
    return { products: loadFallback(), fromFallback: true };
  }
}

module.exports = { searchProducts, normalizeProduct };
