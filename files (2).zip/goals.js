// src/goals.js
// Savings goals. A goal can be linked to a product from Channel3.
// `db` is a pg Pool. All money is in paise. Every function takes the teen's id from the
// logged-in user (never from the request body), so a teen can only touch their own goals.

class GoalError extends Error {
  constructor(code, message) {
    super(message || code);
    this.code = code;
  }
}

function toGoal(row) {
  const target = Number(row.target_paise);
  const saved = Number(row.saved_paise);
  return {
    id: row.id,
    title: row.title,
    targetPaise: target,
    savedPaise: saved,
    percent: target > 0 ? Math.min(100, Math.floor((saved * 100) / target)) : 0,
    reached: saved >= target,
    product: row.product_name
      ? { name: row.product_name, imageUrl: row.product_image_url, link: row.product_link }
      : null,
    createdAt: row.created_at,
  };
}

// product (optional) = { name, imageUrl, link, pricePaise } as returned by /api/goals/search
// If targetPaise is not given, the product's price is used.
async function createGoal(db, teenId, { title, targetPaise, product }) {
  const target = targetPaise !== undefined && targetPaise !== null
    ? targetPaise
    : product && product.pricePaise;

  if (!Number.isInteger(target) || target <= 0) {
    throw new GoalError('INVALID_TARGET', 'Target must be a whole number of paise above 0');
  }
  const goalTitle = (title && String(title).trim()) || (product && product.name);
  if (!goalTitle) throw new GoalError('TITLE_REQUIRED', 'Give the goal a title');

  const r = await db.query(
    `INSERT INTO goals (teen_id, title, target_paise, product_name, product_image_url, product_link)
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
    [
      teenId,
      goalTitle,
      target,
      product ? product.name || null : null,
      product ? product.imageUrl || null : null,
      product ? product.link || null : null,
    ]
  );
  return toGoal(r.rows[0]);
}

async function listGoals(db, teenId) {
  const r = await db.query(
    `SELECT * FROM goals WHERE teen_id = $1 ORDER BY created_at DESC`,
    [teenId]
  );
  return r.rows.map(toGoal);
}

// Set money aside for a goal. It can only come from money the teen has that is not
// already set aside for other goals. This does not change the wallet ledger.
async function addToGoal(db, teenId, goalId, amountPaise) {
  if (!Number.isInteger(amountPaise) || amountPaise <= 0) {
    throw new GoalError('INVALID_AMOUNT', 'Amount must be a whole number of paise above 0');
  }
  const client = await db.connect();
  try {
    await client.query('BEGIN');

    const w = await client.query(`SELECT id FROM wallets WHERE teen_id = $1 FOR UPDATE`, [teenId]);
    if (w.rows.length === 0) throw new GoalError('WALLET_NOT_FOUND', 'No wallet for this teen');

    const g = await client.query(
      `SELECT * FROM goals WHERE id = $1 AND teen_id = $2 FOR UPDATE`,
      [goalId, teenId]
    );
    if (g.rows.length === 0) throw new GoalError('GOAL_NOT_FOUND', 'Goal not found');

    const bal = await client.query(
      `SELECT COALESCE(SUM(amount_paise), 0)::bigint AS balance FROM ledger_entries WHERE wallet_id = $1`,
      [w.rows[0].id]
    );
    const set = await client.query(
      `SELECT COALESCE(SUM(saved_paise), 0)::bigint AS total FROM goals WHERE teen_id = $1`,
      [teenId]
    );
    const available = Number(bal.rows[0].balance) - Number(set.rows[0].total);
    if (amountPaise > available) {
      throw new GoalError('NOT_ENOUGH_AVAILABLE', 'Not enough money available to set aside');
    }

    const u = await client.query(
      `UPDATE goals SET saved_paise = saved_paise + $1 WHERE id = $2 RETURNING *`,
      [amountPaise, goalId]
    );
    await client.query('COMMIT');
    return toGoal(u.rows[0]);
  } catch (err) {
    try { await client.query('ROLLBACK'); } catch (_) { /* ignore */ }
    throw err;
  } finally {
    client.release();
  }
}

async function deleteGoal(db, teenId, goalId) {
  const r = await db.query(`DELETE FROM goals WHERE id = $1 AND teen_id = $2`, [goalId, teenId]);
  if (r.rowCount === 0) throw new GoalError('GOAL_NOT_FOUND', 'Goal not found');
  return { deleted: true };
}

module.exports = { createGoal, listGoals, addToGoal, deleteGoal, GoalError };
