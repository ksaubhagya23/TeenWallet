// Run with: node --test
const test = require('node:test');
const assert = require('node:assert');
const { searchProducts, normalizeProduct } = require('../src/channel3');

test('normalizes the offers[].price.price shape', () => {
  const p = normalizeProduct({
    id: 'a', title: 'Headphones', brand: { name: 'Acme' },
    images: [{ url: 'https://img/1.jpg' }],
    offers: [{ domain: 'shop.com', url: 'https://buy/1', price: { price: 1999.5, currency: 'INR' } }],
  });
  assert.deepStrictEqual(p, {
    productId: 'a', name: 'Headphones', brand: 'Acme', imageUrl: 'https://img/1.jpg',
    link: 'https://buy/1', merchant: 'shop.com', price: 1999.5, currency: 'INR', pricePaise: 199950,
  });
});

test('normalizes the price.amount shape and the flat price shape', () => {
  assert.strictEqual(normalizeProduct({ title: 'x', offers: [{ price: { amount: 110, currency: 'INR' } }] }).pricePaise, 11000);
  const flat = normalizeProduct({ title: 'y', offers: [{ merchant_domain: 'm.com', price: 128, currency: 'INR' }] });
  assert.strictEqual(flat.pricePaise, 12800);
  assert.strictEqual(flat.merchant, 'm.com');
});

test('non-rupee price keeps the price but gives no paise (never save a wrong amount)', () => {
  const p = normalizeProduct({ title: 'z', offers: [{ price: { price: 110, currency: 'USD' } }] });
  assert.strictEqual(p.price, 110);
  assert.strictEqual(p.currency, 'USD');
  assert.strictEqual(p.pricePaise, null);
});

test('reads image_url / image_urls fallbacks and survives missing fields', () => {
  assert.strictEqual(normalizeProduct({ title: 'a', image_url: 'https://i/a.jpg' }).imageUrl, 'https://i/a.jpg');
  assert.strictEqual(normalizeProduct({ title: 'a', image_urls: ['https://i/b.jpg'] }).imageUrl, 'https://i/b.jpg');
  const empty = normalizeProduct({});
  assert.strictEqual(empty.name, null);
  assert.strictEqual(empty.pricePaise, null);
});

test('searchProducts sends key and query, returns normalized products', async () => {
  let seen;
  const fetchFn = async (url, opts) => {
    seen = { url, opts };
    return { ok: true, json: async () => ({ products: [{ id: '1', title: 'Bag', offers: [{ price: { price: 500, currency: 'INR' } }] }] }) };
  };
  const r = await searchProducts('bag', { fetchFn, apiKey: 'KEY' });
  assert.strictEqual(r.fromFallback, false);
  assert.strictEqual(r.products[0].pricePaise, 50000);
  assert.strictEqual(seen.opts.headers['x-api-key'], 'KEY');
  assert.strictEqual(JSON.parse(seen.opts.body).query, 'bag');
});

test('falls back to the saved sample on error, bad status, or missing key', async () => {
  const origWarn = console.warn; console.warn = () => {};
  try {
    const boom = await searchProducts('bag', { fetchFn: async () => { throw new Error('down'); }, apiKey: 'K' });
    const bad = await searchProducts('bag', { fetchFn: async () => ({ ok: false, status: 500 }), apiKey: 'K' });
    const nokey = await searchProducts('bag', { fetchFn: async () => { throw new Error('should not be called'); }, apiKey: '' });
    for (const r of [boom, bad, nokey]) {
      assert.strictEqual(r.fromFallback, true);
      assert.ok(r.products.length > 0);
    }
  } finally { console.warn = origWarn; }
});

test('empty query returns nothing without calling the API', async () => {
  const r = await searchProducts('   ', { fetchFn: async () => { throw new Error('no'); }, apiKey: 'K' });
  assert.deepStrictEqual(r, { products: [], fromFallback: false });
});
